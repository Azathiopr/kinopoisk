import React, { FC } from 'react';
import Main from './components/Main/Main';
import './App.css'

const App: FC = () => {
  return (
    <div>
      <Main />
    </div>
  );
};

export default App;